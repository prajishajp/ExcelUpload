export class transaction
{
	item : string;
    dealnumber:string;
    owner : string;
    itemprofile : string;
    date : string;
    time : string;
    statuss : string;
    currency : string;
    amount : string;
    localequivalent : string;
    valuedate : string;
    stepid : string;
    sender : string;
    customername : string;
    response : string;
    entity : string;
    department : string;
    section : string;
    exceededdate : string;
    
}


